# Data Availability - Flavivirus Host Range Classification

## Overview
This repository contains all data and results for the manuscript:
"Genome-Scale Classification of Flavivirus Host Range Using Composition and Codon-Usage Signatures"

---

## Primary Datasets

### 1. Host Range Classification (Flavivirus, 2-class)
| File | Description | Records |
|------|-------------|---------|
| `model_table_Flavivirus_2class_v1.csv` | Curated Flavivirus dataset with host range labels | 1,285 genomes, 53 species |
| `X_features_v1.csv` | Extracted 97 features + labels + train/val/test splits | 1,285 rows × 100 columns |

### 2. Genus Classification (Flaviviridae, 4-class)
| File | Description | Records |
|------|-------------|---------|
| `Flaviviridae_4genus_index_v1.csv` | Index of all Flaviviridae genomes with genus labels | 4,073 accessions |
| `Flaviviridae_4genus_features.csv` | Extracted 97 features for genus classification | 3,458 genomes, 299 species |

---

## Feature Descriptions

The 97 features extracted from each genome include:

### Compositional Features (n=2)
- `genome_length`: Total genome length in nucleotides
- `gc_content`: GC content as percentage

### Dinucleotide Features (n=34)
- `XX_freq`: Dinucleotide frequencies (16 features: AA, AT, AG, AC, TA, TT, TG, TC, GA, GT, GG, GC, CA, CT, CG, CC)
- `XX_OE`: Dinucleotide observed/expected ratios (18 features including CpG_OE, UpA_OE)

### Codon Usage Features (n=61)
- `RSCU_XXX`: Relative synonymous codon usage for 61 sense codons

---

## Results Files

### Host Range Classification Results
| File | Description |
|------|-------------|
| `ablation_results_v2.csv` | Feature ablation analysis (composition, dinucleotide, RSCU, combined) |
| `length_control_results_v2.csv` | Performance with/without genome length feature |
| `cv_stability_results_v2.csv` | 5-fold species-stratified CV results |
| `cv_statistical_tests_v3.csv` | Wilcoxon signed-rank tests comparing LR vs RF |
| `loso_cv_isfv_species_v1.csv` | Leave-one-species-out CV for 24 ISFV species |

### Feature Importance and Interpretability
| File | Description |
|------|-------------|
| `lr_coefficients_full_v2.csv` | Logistic regression coefficients for all 97 features |
| `rf_importance_full_v2.csv` | Random forest feature importances (MDI) |
| `top15_features_comparison_v2.csv` | Top 15 features for both classifiers |

### Statistical Tests
| File | Description |
|------|-------------|
| `feature_statistics_v2.csv` | Mann-Whitney U tests for Figure 2 (GC, length, CpG, UpA) |
| `statistical_tests_v2.csv` | Mann-Whitney U tests for Figure 6 (misclassified ISFVs) |

### Per-Species Analysis
| File | Description |
|------|-------------|
| `per_species_predictions_v1.csv` | Predicted probabilities for all 53 Flavivirus species |
| `misclassified_feature_comparison_v1.csv` | Feature comparison: correctly vs misclassified ISFVs |

### Genus Classification Results
| File | Description |
|------|-------------|
| `genus_cv_results.csv` | 5-fold CV balanced accuracy and macro F1 |
| `genus_per_class_metrics.csv` | Per-genus precision, recall, F1 scores |
| `genus_feature_importance.csv` | Feature importances for genus classification |

---

## Data Splits

The Flavivirus dataset was split using species-stratified partitioning:

| Split | Genomes | Species | Dual-host | ISFV |
|-------|---------|---------|-----------|------|
| Train | 1,148 | 31 | 1,071 | 77 |
| Validation | 17 | 11 | 4 | 13 |
| Test | 120 | 11 | 103 | 17 |
| **Total** | **1,285** | **53** | **1,178** | **107** |

---

## GenBank Accessions

All genome sequences were retrieved from NCBI GenBank. Accession numbers are provided in:
- `model_table_Flavivirus_2class_v1.csv` (column: `accession`)
- `Flaviviridae_4genus_index_v1.csv` (column: `accession`)
- `merged_accessions_genbank_FINAL_v2.csv` (complete metadata)

---

## Software and Versions

| Software | Version |
|----------|---------|
| Python | 3.10+ |
| Biopython | 1.81 |
| scikit-learn | 1.3.0 |
| SciPy | 1.11.0 |
| pandas | 2.0.0 |
| NumPy | 1.24.0 |
| Matplotlib | 3.7.0 |
| seaborn | 0.12.0 |

---

## Reproducibility

To reproduce the analyses:

1. Download genome sequences from GenBank using accession numbers provided
2. Extract features using the described methods (GC, dinucleotides, RSCU)
3. Use species-stratified splits as specified
4. Train classifiers with `class_weight='balanced'`

All statistical analyses used:
- Mann-Whitney U test for group comparisons
- Wilcoxon signed-rank test for paired comparisons
- Cohen's d for effect sizes

---

## Contact

For questions about data or methods, contact the corresponding author.

---

## License

Data files are provided for academic research purposes. GenBank sequences are subject to NCBI's data usage policies.
